package greenglobal.longht.services;

import java.util.List;

import greenglobal.longht.entity.Post;

public interface PostService {
	public List<Post> listAll();
}
