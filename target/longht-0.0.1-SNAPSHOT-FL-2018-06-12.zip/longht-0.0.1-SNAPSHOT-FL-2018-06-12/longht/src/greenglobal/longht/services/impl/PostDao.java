package greenglobal.longht.services.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import greenglobal.longht.entity.Post;

@Repository
public class PostDao {
	@PersistenceContext
	private EntityManager em;
	@Transactional
	public List<Post> listAll(){
		return em.createQuery("FROM Post",Post.class).getResultList();
	}
}
