package greenglobal.longht.services;

import java.util.List;

import greenglobal.longht.entity.Category;

public interface CategoryService {
	public List<Category> listAll();
}
