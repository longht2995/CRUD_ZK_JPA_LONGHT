package greenglobal.longht;

import greenglobal.longht.entity.Category;
import greenglobal.longht.entity.Log;
import greenglobal.longht.entity.Post;
import greenglobal.longht.services.CategoryService;
import greenglobal.longht.services.MyService;
import greenglobal.longht.services.PostService;

import java.util.List;
import org.zkoss.bind.annotation.BindingParam;
import org.zkoss.bind.annotation.Command;
import org.zkoss.bind.annotation.Init;
import org.zkoss.lang.Strings;
import org.zkoss.zk.ui.select.annotation.VariableResolver;
import org.zkoss.zk.ui.select.annotation.WireVariable;
import org.zkoss.zul.ListModel;
import org.zkoss.zul.ListModelList;

@VariableResolver(org.zkoss.zkplus.spring.DelegatingVariableResolver.class)
public class MyViewModel {
	@WireVariable
	private CategoryService categoryService;
	@WireVariable
	private PostService postService;
	@WireVariable
	private MyService myService;
	private ListModelList<Log> logListModel;
	private String message;
	private ListModelList<Category> categoryListModel;
	private ListModelList<Post> postListModel;
	@Init
	public void init() {
		List<Category> categoryList = categoryService.listAll();
		categoryListModel = new ListModelList<Category>(categoryList);
		List<Post> postList = postService.listAll();
		postListModel = new ListModelList<Post>(postList);
		List<Log> logList = myService.getLogs();
		logListModel = new ListModelList<Log>(logList);
	}
	
	
	public ListModelList<Post> getPostListModel() {
		return postListModel;
	}


	public void setPostListModel(ListModelList<Post> postListModel) {
		this.postListModel = postListModel;
	}


	public ListModelList<Category> getCategoryListModel() {
		return categoryListModel;
	}


	public void setCategoryListModel(ListModelList<Category> categoryListModel) {
		this.categoryListModel = categoryListModel;
	}


	@Command
	public void addLog() {
		if(Strings.isBlank(message)) {
			return;
		}
		Log log = new Log(message);
		log = myService.addLog(log);
		logListModel.add(log);
	}

	@Command
	public void deleteLog(@BindingParam("log") Log log) {
		myService.deleteLog(log);
		logListModel.remove(log);
	}

}
